$(document).ready(function() {
        // Display values
     
});
